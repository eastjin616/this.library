CREATE TABLE COMMENTARY
(
    WRITE_NO NUMBER PRIMARY KEY,
    MEM_NO NUMBER,
    BOOK_NO NUMBER,
    CONTENT VARCHAR2(3000) CONSTRAINT COMMENTARY_CONTENT_NN CHECK (CONTENT IS NOT NULL),
    RATING NUMBER DEFAULT 1 CONSTRAINT COMMENTARY_RATING_NN CHECK (RATING IS NOT NULL),
    WRITE_DATE DATE DEFAULT SYSDATE,

    CONSTRAINT COMMENTARY_MEM_NO_FK FOREIGN KEY(MEM_NO)
    REFERENCES MEMBER(MEM_NO) ON DELETE CASCADE,

    CONSTRAINT COMMENTARY_BOOK_NO_FK FOREIGN KEY(BOOK_NO)
    REFERENCES BOOK(BOOK_NO) ON DELETE CASCADE
);
    
    COMMENT ON COLUMN COMMENTARY.WRITE_NO IS '���� ��ȣ';
    COMMENT ON COLUMN COMMENTARY.MEM_NO IS 'ȸ����ȣ';
    COMMENT ON COLUMN COMMENTARY.BOOK_NO IS 'å��ȣ';
    COMMENT ON COLUMN COMMENTARY.CONTENT IS '���� ����';
    COMMENT ON COLUMN COMMENTARY.RATING IS '����';
    COMMENT ON COLUMN COMMENTARY.WRITE_DATE IS '�ۼ���¥';
    
CREATE SEQUENCE COMMENTARY_SEQ
                INCREMENT BY    1 
                START WITH      1
                MINVALUE        1
                MAXVALUE        99999
                NOCYCLE
                NOCACHE
                NOORDER;
INSERT INTO COMMENTARY(
                WRITE_NO,
                MEM_NO ,
                BOOK_NO,
                CONTENT,
                RATING,
                WRITE_DATE)
            VALUES(COMMENTARY_SEQ.NEXTVAL
                    , 11
                    , 7
                    , 88
                    , '���� �غ��°� ����? �����̼���?'
                    , 4
                    , SYSDATE
                    ); 